//
//  AboutViewController.swift
//  Maryland Covid-19 Chances
//
//  Created by devs on 12/5/20.
//

import UIKit
import WebKit
class AboutViewController: UIViewController {

    @IBOutlet var webview: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()

        webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/null8888888888888888")!))
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
