//
//  CareViewController.swift
//  Maryland Covid-19 Chances
//
//  Created by devs on 11/20/20.
//

import UIKit
import WebKit

class CareViewController: UIViewController {


    //CONNECTIONS
    


    //QUESTIONS
    @IBOutlet weak var favoriteDayTextField: UITextField!

    @IBOutlet weak var infoTrack: UILabel!

    @IBOutlet weak var countyNames: UILabel!
    
    @IBOutlet weak var box1: UIButton!


    
    @IBOutlet weak var box3: UIButton!
    
    
    //VARIABLES

    


    
    let days = ["Allegany County", "Anne Arundel County", "Baltimore", "Baltimore County", "Calvert County", "Caroline County", "Carroll County", "Cecil County", "Charles County", "Dorchester County", "Fredrick County", "Harford County", "Howard County", "Kent County", "Montgomery County", "Prince George's County", "Queen Anne's County", "St. Mary's County", "Washington County", "Wicomico County", "Worchester County"]
           

    
    
    //VARIABLES

    
    var countyPickerView = UIPickerView()
   
    @IBOutlet var webview: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
 
     
        
        
     //CONNECTING TEXTFIELD TO PICKERVIEW
    
        favoriteDayTextField.inputView = countyPickerView

   

    
        //GET DATA FROM ITSELF
        
        
        countyPickerView.delegate = self
        countyPickerView.dataSource = self

 
        //TAG NAMES
        
        countyPickerView.tag = 1
     
        createDayPicker()
          createToolbar()
      }
      func createDayPicker () {
        
        countyPickerView.backgroundColor = .systemTeal
   
      }
      

//COLOR TOOLBAR
  func createToolbar () {
      
      let toolBar = UIToolbar()
      toolBar.sizeToFit()

      toolBar.barTintColor = .black
      toolBar.tintColor = .white
      
      let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(MainViewController.dismissKeyboard))
      
      toolBar.setItems([doneButton], animated: false)
      toolBar.isUserInteractionEnabled = true
      
      favoriteDayTextField.inputAccessoryView = toolBar
 
  }

      @objc func dismissKeyboard () {
          view.endEditing(true)
          
          
      
      }
        
        
    }



extension CareViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    
    //RETURN ONE DATASET
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        //GET THESE DATASETS
        
        switch pickerView.tag {
        case 1:
        
            return days.count
     
        default:
            return 1
        }
    }
        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            //GET THESE DATASETS
          
            switch pickerView.tag {
             case 1:
        
                return days[row]
                

            default:
                return "Data not found."
            }
        }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        //GET THESE DATASETS AND SHOW IT ON TEXTFIELD
//IF THIS IS SELECTED ADD TO PERCENTAGE
        switch pickerView.tag {
        case 1:
        
            favoriteDayTextField.text = days[row]
            favoriteDayTextField.resignFirstResponder()
            infoTrack.text = days[row]
            infoTrack.resignFirstResponder()
            
            if favoriteDayTextField.text! == "Prince George's County" {
                countyNames.text! = "Prince George's County Primary Care Physician Doctors"
                    
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/03000ppxlbo99494null/1")!))
                
                box3.isHidden = true

        
                        
            
                                                                           
                                                                       }
            if favoriteDayTextField.text! == "Montgomery County" {
                countyNames.text! = "Montgomery County Primary Care Physician Doctors"
                    
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/03000ppxlbo99494null/copy-of-3-1")!))
                box3.isHidden = true
                                            }
            if favoriteDayTextField.text! == "Baltimore County" {
                countyNames.text! = "Baltimore County Primary Care Physician Doctors"
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/03000ppxlbo99494null/copy-of-2-1")!))
                box3.isHidden = true
                                               }

            if favoriteDayTextField.text! == "Baltimore" {
                countyNames.text! = "Baltimore Primary Care Physician Doctors"
      

                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/03000ppxlbo99494null/copy-of-9-1")!))
                box3.isHidden = true                                              }
            if favoriteDayTextField.text! == "Anne Arundel County" {
                countyNames.text! = "Anne Arundel County Primary Care Physician Doctors"
      
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/03000ppxlbo99494null/copy-of-16")!))
                box3.isHidden = true
                
                
                                                                         
                                                                     }
            
            if favoriteDayTextField.text! == "Howard County" {
     
                countyNames.text! = "Howard County Primary Care Physician Doctors"
      
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/03000ppxlbo99494null/copy-of-17-1")!))
                box3.isHidden = true                                                  }
            
            if favoriteDayTextField.text! == "Fredrick County" {
                
                countyNames.text! = "Fredrick County Primary Care Physician Doctors"
              
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/03000ppxlbo99494null/copy-of-21")!))
                
                box3.isHidden = true
                                                                 }
            if favoriteDayTextField.text! == "Charles County" {
             
                countyNames.text! = "Charles County Primary Care Physician Doctors"
      
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/03000ppxlbo99494null/copy-of-25")!))
                box3.isHidden = true
                
   
                                                                     }

            if favoriteDayTextField.text! == "Harford County" {
                countyNames.text! = "Harford County Primary Care Physician Doctors"
      
                box3.isHidden = true
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/03000ppxlbo99494null/copy-of-29")!))
                
                
                
                
      
                                                               }
            if favoriteDayTextField.text! == "Carroll County" {
        
                
                countyNames.text! = "Carroll County Primary Care Physician Doctors"
      
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/03000ppxlbo99494null/copy-of-33")!))
                box3.isHidden = true
                
                
                
   
                                                   
                                                                   }
            if favoriteDayTextField.text! == "Wicomico County" {
         
                countyNames.text! = "Wicomico County Primary Care Physician Doctors"
      
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/03000ppxlbo99494null/copy-of-37")!))
                
                box3.isHidden = true
        
                                                       
                                                                       }
            if favoriteDayTextField.text! == "Washington County" {
            
                countyNames.text! = "Washington County Primary Care Physician Doctors"
      
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/03000ppxlbo99494null/copy-of-41")!))
                
                box3.isHidden = true
                                                                           }
            if favoriteDayTextField.text! == "St. Mary's County" {
            
                
                countyNames.text! = "St. Mary's County Primary Care Physician Doctors"
      
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/website/1")!))
    
                box3.isHidden = true
                                                                                   }
            if favoriteDayTextField.text! == "Cecil County" {
              
                countyNames.text! = "Cecil County Primary Care Physician Doctors"
      
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/website/copy-of-3-1")!))
                box3.isHidden = true
                     
                                                                       }
            if favoriteDayTextField.text! == "Calvert County" {
                countyNames.text! = "Calvert County Primary Care Physician Doctors"
                box3.isHidden = true
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/website/copy-of-2-1")!))
                                         
                                                                                     }
            if favoriteDayTextField.text! == "Caroline County" {
             
                countyNames.text! = "Caroline County Primary Care Physician Doctors"
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/website/copy-of-9-1")!))
                box3.isHidden = true
                                              
                                                                                        }
            if favoriteDayTextField.text! == "Worchester County" {
                
                
                
                countyNames.text! = "Worchester County Primary Care Physician Doctors"
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/website/copy-of-16")!))
                box3.isHidden = true
                                                                                 }
            if favoriteDayTextField.text! == "Queen Anne's County" {
            
                countyNames.text! = "Queen Anne's County Primary Care Physician Doctors"
                box3.isHidden = true
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/website/copy-of-17-1")!))
   
            }
            if favoriteDayTextField.text! == "Allegany County" {
            
                countyNames.text! = "Allegany Primary Care Physician Doctors"
                box3.isHidden = true
                webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/website/copy-of-17-1")!))
   
            }
        
     
        default:
            return
            
        
        
            }
    
    }
    
    
}
    

