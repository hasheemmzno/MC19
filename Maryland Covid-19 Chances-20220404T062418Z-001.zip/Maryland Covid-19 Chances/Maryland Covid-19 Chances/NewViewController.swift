//
//  NewViewController.swift
//  Maryland Covid-19 Chances
//
//  Created by devs on 12/4/20.
//

import UIKit
import WebKit
import UserNotifications

class NewViewController: UIViewController {

    
    @IBOutlet var webview: WKWebView!
  
    
    override func viewDidLoad() {
        super.viewDidLoad()

        webview.load(URLRequest(url: URL(string: "https://strifepetterson199.wixsite.com/Hryryhrhryhry220null")!))
        
        let center = UNUserNotificationCenter.current()
              center.requestAuthorization(options: [.alert, .sound])
              { (granted, error) in
                  
              }
              let content = UNMutableNotificationContent()
              content.title = "New News Article"
              content.body = "There is a new article for MCC check it out"
              content.sound = .default
          
            
              
              var dateComponents = DateComponents()
          dateComponents.calendar = Calendar.current
              dateComponents.hour = 9
              dateComponents.minute = 30
              
              
              let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
              
             
              let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
              
              center.add(request)
        
        
        
        let center1 = UNUserNotificationCenter.current()
              center1.requestAuthorization(options: [.alert, .sound])
              { (granted, error) in
                  
              }
              let content1 = UNMutableNotificationContent()
              content1.title = "New News Article"
              content1.body = "There is a new article for MCC check it out"
              content1.sound = .default
          
            
              
              var dateComponents1 = DateComponents()
          dateComponents1.calendar = Calendar.current
              dateComponents1.hour = 12
              dateComponents1.minute = 00
              
              
              let trigger1 = UNCalendarNotificationTrigger(dateMatching: dateComponents1, repeats: true)
              
             
              let request1 = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger1)
              
              center1.add(request1)
                  
        
        // Do any additional setup after loading the view.
    

    let center2 = UNUserNotificationCenter.current()
          center2.requestAuthorization(options: [.alert, .sound])
          { (granted, error) in
              
          }
          let content2 = UNMutableNotificationContent()
          content2.title = "New News Article"
          content2.body = "There is a new article for MCC check it out"
          content2.sound = .default
      
        
          
          var dateComponents2 = DateComponents()
      dateComponents2.calendar = Calendar.current
          dateComponents2.hour = 14
          dateComponents2.minute = 30
          
          
          let trigger2 = UNCalendarNotificationTrigger(dateMatching: dateComponents2, repeats: true)
          
         
          let request2 = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger2)
          
          center2.add(request2)
    
    
        let center3 = UNUserNotificationCenter.current()
              center3.requestAuthorization(options: [.alert, .sound])
              { (granted, error) in
                  
              }
              let content3 = UNMutableNotificationContent()
              content3.title = "New News Article"
              content3.body = "There is a new article for MCC check it out"
              content3.sound = .default
          
            
              
              var dateComponents3 = DateComponents()
          dateComponents3.calendar = Calendar.current
              dateComponents3.hour = 21
              dateComponents3.minute = 00
              
              
              let trigger3 = UNCalendarNotificationTrigger(dateMatching: dateComponents3, repeats: true)
              
             
              let request3 = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger3)
              
              center3.add(request3)
                  
        
        // Do any additional setup after loading the view.
    
        
        

}
    
    

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

