//
//  MainViewController.swift
//  Maryland Covid-19 Chances
//
//  Created by devs on 10/31/20.
//

import UIKit

class MainViewController: UIViewController {

    //CONNECTIONS
    

  
    

    @IBOutlet weak var favoriteDayTextField: UITextField!
    @IBOutlet weak var ageTextField: UITextField!

    @IBOutlet weak var yesOrNo: UITextField!

    @IBOutlet weak var AroundPeople: UITextField!
    
    @IBOutlet weak var percent: UILabel!
    


    
    //VARIABLES

let vc1 = ViewController()
    
    
    
    var firstBox: Bool = false;
    var secondBox: Bool = false;
    var thirdBox: Bool = false;
    var fourthBox: Bool = false;
    
    
    var formatter = NumberFormatter()
    //GET RESULTS
  
    @IBOutlet weak var box1: UIButton!
    @IBOutlet weak var box2: UIButton!
    @IBOutlet weak var box3: UIButton!
    @IBOutlet weak var box4: UIButton!
    
    
    @IBAction func getResults(_ sender: UIButton) {
       
     
        
        
        print(vc1.results2)
        
        
        
        //SET RESULTS AS 0
        

        
        vc1.results = Float(0.0)
        
        
       
        
        //PLEASE DONT SPAM THE DECIMALS
        
        formatter.maximumFractionDigits = 2
        formatter.minimumFractionDigits = 2
        
        //WHAT I WANT IN THE RESULTS
        
        if let formattedString = formatter.string(for: (vc1.percentage + vc1.age + vc1.already) * (vc1.No1) * (vc1.Yes1) + vc1.results ) {
        
            percent.text = "\(formattedString)%"
        
          
    
            
            if firstBox == Bool(false) {
               
                print("Answer question")
                
                    percent.text = ""
                box1.isHidden = false
            
            } else {
                
                box1.isHidden = true
            }
            if secondBox == Bool(false) {
               
                print("Answer  question ")
                
                    percent.text = ""
                box2.isHidden = false
            }else {
                
                box2.isHidden = true
            }
            if thirdBox == Bool(false) {
               
                print("Answer  question ")
                
                    percent.text = ""
                box3.isHidden = false
            }else {
                
                box3.isHidden = true
            }
            if fourthBox == Bool(false) {
               
                print("Answer question ")
                
                    percent.text = ""
                box4.isHidden = false
            } else {
                
                box4.isHidden = true
            }
            
            
                            
                        }
                }
            
        
    
         
    


        
    //DATASETS LIKE COUNTIES AGE AND YES OR NO QUESTIONS
    
   
    
    
    //VARIABLES

    
    var countyPickerView = UIPickerView()
    var agePickerView = UIPickerView()
    var yesOrNoPickerView = UIPickerView()
    var AroundPeoplePickerView = UIPickerView()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
     //CONNECTING TEXTFIELD TO PICKERVIEW
    
        favoriteDayTextField.inputView = countyPickerView
        ageTextField.inputView = agePickerView
        yesOrNo.inputView = yesOrNoPickerView
        AroundPeople.inputView = AroundPeoplePickerView
       

   
        //TEXTFIELD PLACEHOLDER
        
        
        favoriteDayTextField.placeholder = "Select County"
        ageTextField.placeholder = "Select Age"
        yesOrNo.placeholder = "Have You Been Around People?"
        AroundPeople.placeholder = "Do you wash your hands frequently?"
    
        //GET DATA FROM ITSELF
        
        
        countyPickerView.delegate = self
        countyPickerView.dataSource = self
        agePickerView.delegate = self
        agePickerView.dataSource = self
        yesOrNoPickerView.delegate = self
        AroundPeoplePickerView.delegate = self
        yesOrNoPickerView.dataSource = self
        AroundPeoplePickerView.dataSource = self
        

        //TAG NAMES
        
        countyPickerView.tag = 1
        agePickerView.tag = 2
        yesOrNoPickerView.tag = 3
        AroundPeoplePickerView.tag = 4
   
        
        createDayPicker()
          createToolbar()
      }
      func createDayPicker () {
        
        countyPickerView.backgroundColor = .systemTeal
        agePickerView.backgroundColor = .systemTeal
        yesOrNoPickerView.backgroundColor = .systemTeal
        AroundPeoplePickerView.backgroundColor = .systemTeal
    
      }
      

//COLOR TOOLBAR
  func createToolbar () {
      
      let toolBar = UIToolbar()
      toolBar.sizeToFit()

      toolBar.barTintColor = .black
      toolBar.tintColor = .white
      
      let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(MainViewController.dismissKeyboard))
      
      toolBar.setItems([doneButton], animated: false)
      toolBar.isUserInteractionEnabled = true
      
      favoriteDayTextField.inputAccessoryView = toolBar
      ageTextField.inputAccessoryView = toolBar
      yesOrNo.inputAccessoryView = toolBar
      AroundPeople.inputAccessoryView = toolBar
    
  }

      @objc func dismissKeyboard () {
          view.endEditing(true)
          
          
      
      }
        
        
    }



extension MainViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    
    //RETURN ONE DATASET
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        //GET THESE DATASETS
        
        switch pickerView.tag {
        case 1:
        
            return vc1.days.count
        
        case 2:
            
            return vc1.days1.count
            
        case 3:
        
            return vc1.yesOrNo1.count
        case 4:
        
            return vc1.yesOrNo2.count
            
 
        default:
            return 1
            
        }
    }
        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            //GET THESE DATASETS
          
            switch pickerView.tag {
             case 1:
        
                return vc1.days[row]
                
             case 2:
                 
                return vc1.days1[row]
                 
             case 3:
             
                return vc1.yesOrNo1[row]
            case 4:
            
                return vc1.yesOrNo2[row]
                
             default:
                 return "Data not found."
                 
             }
          
        }
 
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        //GET THESE DATASETS AND SHOW IT ON TEXTFIELD
//IF THIS IS SELECTED ADD TO PERCENTAGE
        switch pickerView.tag {
        case 1:
        
            favoriteDayTextField.text = vc1.days[row]
            favoriteDayTextField.resignFirstResponder()
         
            
            if favoriteDayTextField.text! == "Prince George's County" {
                
                firstBox = Bool(true)
            
                vc1.percentage = Float(1.5)
            
                                                                           
                                                                       }
            if favoriteDayTextField.text! == "Montgomery County" {
                firstBox = Bool(true)
                vc1.percentage = Float(1.5)
          
                                      
                                                
                                            }
            if favoriteDayTextField.text! == "Baltimore County" {
                firstBox = Bool(true)
                vc1.percentage = Float(1.1)
      
                                                   
                                               }

            if favoriteDayTextField.text! == "Baltimore" {
                firstBox = Bool(true)
                vc1.percentage = Float(1.4)
            
                                                                         
                                                                     }
            if favoriteDayTextField.text! == "Anne Arundel County" {
                firstBox = Bool(true)
                vc1.percentage = Float(0.9)
         
                                                                         
                                                                     }
            if favoriteDayTextField.text! == "Howard County" {
                firstBox = Bool(true)
                vc1.percentage = Float(0.9)

                                                                         
                                                                     }
            if favoriteDayTextField.text! == "Fredrick County" {
                firstBox = Bool(true)
                vc1.percentage = Float(1.0)
           
                                              
                                                                 }
            if favoriteDayTextField.text! == "Charles County" {
                firstBox = Bool(true)
                vc1.percentage = Float(0.9)
   
                                                                     }

            if favoriteDayTextField.text! == "Harford County" {
                firstBox = Bool(true)
                vc1.percentage = Float(0.5)
      
                                                               }
            if favoriteDayTextField.text! == "Carroll County" {
                firstBox = Bool(true)
                vc1.percentage = Float(0.7)
   
                                                   
                                                                   }
            if favoriteDayTextField.text! == "Wicomico County" {
                firstBox = Bool(true)
                vc1.percentage = Float(0.9)
        
                                                       
                                                                       }
            if favoriteDayTextField.text! == "Washington County" {
                firstBox = Bool(true)
                vc1.percentage = Float(0.9)
       
                                                                           }
            if favoriteDayTextField.text! == "St. Mary's County" {
                firstBox = Bool(true)
                vc1.percentage = Float(0.6)
    
                                                                   
                                                                                   }
            if favoriteDayTextField.text! == "Cecil County" {
                firstBox = Bool(true)
                vc1.percentage = Float(0.5)
                     
                                                                       }
            if favoriteDayTextField.text! == "Calvert County" {
                firstBox = Bool(true)
                vc1.percentage = Float(0.5)
                                         
                                                                                     }
            if favoriteDayTextField.text! == "Caroline County" {
                firstBox = Bool(true)
                vc1.percentage = Float(1.1)
                                              
                                                                                        }
            if favoriteDayTextField.text! == "Worcester County" {
                firstBox = Bool(true)
                vc1.percentage = Float(1.4)
                                    
                                                                                               }
            if favoriteDayTextField.text! == "Queen Anne's County" {
                firstBox = Bool(true)
                vc1.percentage = Float(0.6)
   
            }
            
            
        case 2:
            //IF THIS IS SELECTED ADD TO PERCENTAGE
            ageTextField.text = vc1.days1[row]
            ageTextField.resignFirstResponder()

            if ageTextField.text! == "65 - 100" {
                secondBox = Bool(true)
                vc1.age = Float(2.04)
            }
 
            if ageTextField.text! == "50 - 64" {
                secondBox = Bool(true)
                vc1.age = Float(1.52)
            }
            if ageTextField.text! == "35 - 49" {
                secondBox = Bool(true)
                vc1.age = Float(1.52)
            }
            if ageTextField.text! == "20 - 34" {
                secondBox = Bool(true)
                vc1.age = Float(1.52)
            }
            if ageTextField.text! == "13 - 19" {
                secondBox = Bool(true)
                vc1.age = Float(0.52)
            }
            if ageTextField.text! == "3 - 12" {
                secondBox = Bool(true)
                vc1.age = Float(0.52)
            }
            
        case 3:
            //IF THIS IS SELECTED ADD TO PERCENTAGE
            yesOrNo.text = vc1.yesOrNo1[row]
            yesOrNo.resignFirstResponder()
  
            if yesOrNo.text! == "No" {
                thirdBox = Bool(true)
                vc1.results = Float(0.0)
                
                //SET RESULTS AS 3
                vc1.No1 = Float(0.5)
            }
                if yesOrNo.text! == "Yes" {
                    thirdBox = Bool(true)
                    vc1.results = Float(0.0)
                    
                    //SET RESULTS AS 3
                    vc1.No1 = Float(2.0)
                    
                    
                    
                }
            
                    
                    
            
        case 4:
            //IF THIS IS SELECTED ADD TO PERCENTAGE
            AroundPeople.text = vc1.yesOrNo2[row]
            AroundPeople.resignFirstResponder()
            
            if AroundPeople.text! == "No" {
                fourthBox = Bool(true)
                vc1.results = Float(0.0)
                
                //SET RESULTS AS 3
                vc1.Yes1 = Float(1.20)
            }
                if AroundPeople.text! == "Yes" {
                    fourthBox = Bool(true)
                    vc1.results = Float(0.0)
                    
                    //SET RESULTS AS 3
                    vc1.Yes1 = Float(0.60)
                    
                    
                    
                }
           
        default:
            return
            
        
        
            }
    
    }
    
    
}
    
